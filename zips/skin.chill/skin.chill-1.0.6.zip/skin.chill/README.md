Pellucid
===================

[![Pellucid](http://img.youtube.com/vi/QYzGpAwfgaw/0.jpg)](https://www.youtube.com/watch?v=QYzGpAwfgaw "Pellucid")

Pellucid is a skin for Kodi Media Centre.

Built for the living room, Pellucid is a clean and simple Kodi experience designed for maximum usability and minimum fuss.

Skin Shortcuts addon support is available from the Krypton release onwards.

Discussion thread: http://forum.kodi.tv/forumdisplay.php?fid=267

Created by theDeadMan with love from Bristol, U.K.

